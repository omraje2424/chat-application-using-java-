package org.example;

import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class SignupFrame extends JFrame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ChatDB";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Morya@123";

    public SignupFrame() {
        setTitle("Signup");
        setSize(300, 200);
        setLayout(null);

        // Set background color for the frame
        getContentPane().setBackground(new Color(255, 248, 220)); // Cornsilk background

        // "Username" label
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 30, 100, 25);
        userLabel.setFont(new Font("Cambria Math", Font.BOLD, 14)); // Set font
        add(userLabel);

        // Text field for username input
        JTextField userText = new JTextField();
        userText.setBounds(130, 30, 120, 25);
        userText.setFont(new Font("Cambria Math", Font.PLAIN, 14)); // Set font
        add(userText);

        // "Password" label
        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 70, 100, 25);
        passLabel.setFont(new Font("Cambria Math", Font.BOLD, 14)); // Set font
        add(passLabel);

        // Password field for password input
        JPasswordField passText = new JPasswordField();
        passText.setBounds(130, 70, 120, 25);
        passText.setFont(new Font("Cambria Math", Font.PLAIN, 14)); // Set font
        add(passText);

        // Signup button
        JButton signupButton = new JButton("Signup");
        signupButton.setBounds(90, 110, 100, 30);
        signupButton.setFont(new Font("Cambria Math", Font.BOLD, 14)); // Set font
        signupButton.setForeground(Color.WHITE);  // Set text color
        signupButton.setBackground(new Color(70, 130, 180)); // Steel blue background
        add(signupButton);

        // Action listener for signup button
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = String.valueOf(passText.getPassword());

                if (signupUser(username, password)) {
                    JOptionPane.showMessageDialog(null, "Signup Successful");
                    // Here you can add the code to proceed after successful signup
                } else {
                    JOptionPane.showMessageDialog(null, "Signup Failed. Try Again.");
                }
            }
        });

        // Set frame visibility
        setVisible(true);
    }

    // Method to insert a new user into the database
    private boolean signupUser(String username, String password) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO users (username, password) VALUES (?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);

            return stmt.executeUpdate() > 0; // If insertion is successful, return true
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }
}
