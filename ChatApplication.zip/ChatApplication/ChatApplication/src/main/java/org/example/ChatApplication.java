package org.example;

import javax.swing.*;
import java.sql.*;

public class ChatApplication {

    public static void startChat(String username) {
        // Create login for both users
        String username1 = username;
        String username2 = loginUser("Chat Partner's Login");

        // Create a chat session between the two users
        int sessionId = createChatSession(username1, username2);

        // Create two chat windows with usernames
        ChatWindow chatWindow1 = new ChatWindow(username1, sessionId);
        ChatWindow chatWindow2 = new ChatWindow(username2, sessionId);

        // Link the chat windows
        chatWindow1.setChatPartner(chatWindow2);
        chatWindow2.setChatPartner(chatWindow1);

        // Display both windows
        chatWindow1.setVisible(true);
        chatWindow2.setVisible(true);
    }

    // Method to display login window
    private static String loginUser(String title) {
        String username = JOptionPane.showInputDialog(null, "Enter username:", title, JOptionPane.PLAIN_MESSAGE);
        while (username == null || username.trim().isEmpty()) {
            username = JOptionPane.showInputDialog(null, "Username cannot be empty. Enter username:", title, JOptionPane.ERROR_MESSAGE);
        }
        return username.trim();
    }

    // Method to create or retrieve a chat session between two users
    private static int createChatSession(String user1, String user2) {
        int sessionId = -1;
        final String DB_URL = "jdbc:mysql://localhost:3306/ChatDB";
        final String DB_USER = "root";
        final String DB_PASSWORD = "Morya@123";

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            // Check if a session already exists between these two users
            String checkQuery = "SELECT session_id FROM chat_sessions WHERE (user1 = ? AND user2 = ?) OR (user1 = ? AND user2 = ?)";
            PreparedStatement checkStmt = conn.prepareStatement(checkQuery);
            checkStmt.setString(1, user1);
            checkStmt.setString(2, user2);
            checkStmt.setString(3, user2);
            checkStmt.setString(4, user1);
            ResultSet rs = checkStmt.executeQuery();

            if (rs.next()) {
                sessionId = rs.getInt("session_id");
            } else {
                // Create a new session if none exists
                String insertQuery = "INSERT INTO chat_sessions (user1, user2) VALUES (?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertQuery, Statement.RETURN_GENERATED_KEYS);
                insertStmt.setString(1, user1);
                insertStmt.setString(2, user2);
                insertStmt.executeUpdate();

                // Get the generated session ID
                ResultSet generatedKeys = insertStmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    sessionId = generatedKeys.getInt(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sessionId;
    }
}
