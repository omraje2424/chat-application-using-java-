package org.example;

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

class ChatWindow extends JFrame {
    private String username;
    private int sessionId;  // Store the session ID for unique chat sessions
    private JTextPane chatArea;
    private JTextPane inputField;
    private JButton sendButton;
    private JComboBox<String> emojiComboBox;
    private JButton boldButton, italicButton, underlineButton;
    private ChatWindow chatPartner;

    // Database connection details
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ChatDB";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Morya@123";

    public ChatWindow(String username, int sessionId) {
        this.username = username;
        this.sessionId = sessionId;

        // Set up the frame
        setTitle(username + "'s Chat Window");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Set background color for the chat window
        getContentPane().setBackground(new Color(230, 230, 250));  // Lavender background

        // Create chat area with custom font
        chatArea = new JTextPane();
        chatArea.setEditable(false);
        chatArea.setFont(new Font("Cambria Math", Font.PLAIN, 14));  // Set font
        chatArea.setBackground(new Color(245, 245, 245));  // Light gray background
        chatArea.setForeground(Color.DARK_GRAY);  // Text color

        // Create input field as JTextPane to support styled text (bold, italic, underline)
        inputField = new JTextPane();
        inputField.setFont(new Font("Cambria Math", Font.PLAIN, 14));  // Set font

        // Create emoji combo box with emojis
        String[] emojis = {"😊", "😂", "😍", "👍", "🔥", "💔", "🎉", "❤️"};
        emojiComboBox = new JComboBox<>(emojis);
        emojiComboBox.addActionListener(e -> insertEmoji());

        // Create buttons for bold, italic, and underline text
        boldButton = new JButton("B");
        boldButton.setFont(new Font("Cambria Math", Font.BOLD, 14));
        boldButton.addActionListener(e -> toggleBold());

        italicButton = new JButton("I");
        italicButton.setFont(new Font("Cambria Math", Font.ITALIC, 14));
        italicButton.addActionListener(e -> toggleItalic());

        underlineButton = new JButton("U");
        underlineButton.setFont(new Font("Cambria Math", Font.PLAIN, 14));
        underlineButton.addActionListener(e -> toggleUnderline());

        // Create send button
        sendButton = new JButton("Send");
        sendButton.setFont(new Font("Cambria Math", Font.BOLD, 14));  // Set font
        sendButton.setForeground(Color.WHITE);  // Button text color
        sendButton.setBackground(new Color(70, 130, 180));  // Steel blue button background

        // Set up listeners for sending messages
        sendButton.addActionListener(e -> sendMessage());

        // Add components to the frame
        add(new JScrollPane(chatArea), BorderLayout.CENTER);

        // Create panel for input field, buttons, and emoji combo box
        JPanel inputPanel = new JPanel(new BorderLayout());
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(boldButton);
        buttonPanel.add(italicButton);
        buttonPanel.add(underlineButton);
        buttonPanel.add(emojiComboBox);

        inputPanel.add(new JScrollPane(inputField), BorderLayout.CENTER);
        inputPanel.add(buttonPanel, BorderLayout.NORTH);
        inputPanel.add(sendButton, BorderLayout.EAST);
        
        add(inputPanel, BorderLayout.SOUTH);

        // Load previous messages for this chat session
        loadChatHistory();
    }

    public void setChatPartner(ChatWindow chatPartner) {
        this.chatPartner = chatPartner;
    }

    // Method to insert selected emoji into the input field
    private void insertEmoji() {
        String selectedEmoji = (String) emojiComboBox.getSelectedItem();
        if (selectedEmoji != null) {
            inputField.replaceSelection(selectedEmoji);  // Insert emoji at the caret position
        }
    }

    // Method to send messages
    private void sendMessage() {
        String message = inputField.getText().trim();
        if (!message.isEmpty()) {
            String timestamp = getCurrentTimestamp();
            appendMessage(username + " [" + timestamp + "]: " + message);
            storeMessageInDatabase(username, message, timestamp);  // Store in the database
            if (chatPartner != null) {
                chatPartner.receiveMessage(username, message, timestamp);
            }
            inputField.setText("");  // Clear the input field after sending
        }
    }

    public void receiveMessage(String sender, String message, String timestamp) {
        appendMessage(sender + " [" + timestamp + "]: " + message);
    }

    private void appendMessage(String message) {
        chatArea.setText(chatArea.getText() + message + "\n");
    }

    // Method to get the current date and time as a formatted string
    private String getCurrentTimestamp() {
        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return now.format(formatter);
    }

    // Method to store the message in the database
    private void storeMessageInDatabase(String username, String message, String timestamp) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "INSERT INTO chat_messages (session_id, sender, message, timestamp) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, sessionId);
            stmt.setString(2, username);
            stmt.setString(3, message);
            stmt.setString(4, timestamp);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to load the chat history for this session from the database
    private void loadChatHistory() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT sender, message, timestamp FROM chat_messages WHERE session_id = ? ORDER BY timestamp ASC";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, sessionId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String sender = rs.getString("sender");
                String message = rs.getString("message");
                String timestamp = rs.getString("timestamp");
                appendMessage(sender + " [" + timestamp + "]: " + message);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Methods to toggle text styles (bold, italic, underline)
    private void toggleBold() {
        toggleStyle(StyleConstants.Bold);
    }

    private void toggleItalic() {
        toggleStyle(StyleConstants.Italic);
    }

    private void toggleUnderline() {
        toggleStyle(StyleConstants.Underline);
    }

    private void toggleStyle(Object styleConstant) {
        StyledDocument doc = inputField.getStyledDocument();
        SimpleAttributeSet attributes = new SimpleAttributeSet();

        if (styleConstant == StyleConstants.Bold) {
            StyleConstants.setBold(attributes, !StyleConstants.isBold(attributes));
        } else if (styleConstant == StyleConstants.Italic) {
            StyleConstants.setItalic(attributes, !StyleConstants.isItalic(attributes));
        } else if (styleConstant == StyleConstants.Underline) {
            StyleConstants.setUnderline(attributes, !StyleConstants.isUnderline(attributes));
        }

        doc.setCharacterAttributes(inputField.getSelectionStart(), inputField.getSelectionEnd() - inputField.getSelectionStart(), attributes, false);
    }
}
