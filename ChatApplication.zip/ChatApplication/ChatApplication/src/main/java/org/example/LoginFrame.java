package org.example;

import javax.swing.*;
import java.awt.Color; // Import Color
import java.awt.Font;  // Import Font
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoginFrame extends JFrame {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/ChatDB";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "Morya@123";

    public LoginFrame() {
        setTitle("Login");
        setSize(300, 200);
        setLayout(null);
        
        // Set background color for the frame
        getContentPane().setBackground(new Color(173, 216, 230));  // Light blue

        // Username Label
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 30, 100, 25);
        userLabel.setFont(new Font("Cambria Math", Font.PLAIN, 12)); // Set font
        add(userLabel);

        // Username Text Field
        JTextField userText = new JTextField();
        userText.setBounds(130, 30, 120, 25);
        userText.setFont(new Font("Cambria Math", Font.PLAIN, 12)); // Set font
        add(userText);

        // Password Label
        JLabel passLabel = new JLabel("Password:");
        passLabel.setBounds(50, 70, 100, 25);
        passLabel.setFont(new Font("Cambria Math", Font.PLAIN, 12)); // Set font
        add(passLabel);

        // Password Field
        JPasswordField passText = new JPasswordField();
        passText.setBounds(130, 70, 120, 25);
        passText.setFont(new Font("Cambria Math", Font.PLAIN, 12)); // Set font
        add(passText);

        // Login Button
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(90, 110, 100, 30);
        loginButton.setFont(new Font("Cambria Math", Font.BOLD, 12)); // Set font
        loginButton.setBackground(new Color(255, 255, 153)); // Light yellow background
        loginButton.setForeground(new Color(255, 0, 0)); // Red text
        add(loginButton);

        // ActionListener for login button
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = String.valueOf(passText.getPassword());

                if (loginUser(username, password)) {
                    JOptionPane.showMessageDialog(null, "Login Successful");
                    dispose();  // Close the login window

                    // Start Chat Application after successful login
                    ChatApplication.startChat(username);
                } else {
                    JOptionPane.showMessageDialog(null, "Login Failed. Try Again.");
                }
            }
        });

        setVisible(true);
    }

    // Method to check the login credentials
    private boolean loginUser(String username, String password) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            String query = "SELECT * FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            return rs.next(); // If user exists, return true
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return false;
    }

    public static void main(String[] args) {
        // Run the LoginFrame
        new LoginFrame();
    }
}
