package org.example;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ChatAppMain {

    public static void main(String[] args) {
            JFrame frame = new JFrame("Loading...");
            JLabel headingLabel = new JLabel("Chat Application is Loading...", JLabel.CENTER);
            JProgressBar progressBar = new JProgressBar(0, 100);
            progressBar.setStringPainted(true);

            // Increase the font size of the label
            headingLabel.setFont(new Font("Cambria Math", Font.BOLD| Font.ITALIC, 40));  // Change the font size here

            // Set the background color of the frame
            frame.getContentPane().setBackground(Color.cyan); // Set background color (e.g., Light Gray)


        // Forcefully reduce the height of the progress bar
         Dimension progressBarSize = new Dimension(900, 25); // Width: 400, Height: 15
         progressBar.setPreferredSize(progressBarSize);
         progressBar.setMinimumSize(progressBarSize);
        progressBar.setMaximumSize(progressBarSize);

            // Set layout to center the progress bar and label
            frame.setLayout(new BorderLayout());

            // Add the heading label at the top
            frame.add(headingLabel, BorderLayout.NORTH);

            // Create a panel to hold the progress bar and center it
            JPanel centerPanel = new JPanel(new GridBagLayout());
            centerPanel.setBackground(Color.cyan);

            // Configure GridBagConstraints for centering
            GridBagConstraints gbc = new GridBagConstraints();
            gbc.gridx = 0;
            gbc.gridy = 0;
            gbc.insets = new Insets(10, 10, 10, 10); // Add spacing around the components

            centerPanel.add(progressBar, gbc);
            frame.add(centerPanel, BorderLayout.CENTER);
            frame.setSize(900, 500);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);


            // Simulate loading with a thread
            for (int i = 0; i <= 100; i++) {
                final int percent = i;
                SwingUtilities.invokeLater(() -> progressBar.setValue(percent));
                try {
                    Thread.sleep(30); // Simulate loading time
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            frame.dispose(); // Close loading screen when done
        // Create Main Chat Frame
        JFrame mainFrame = new JFrame("Chat Application");
        mainFrame.setSize(400, 300);
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setLayout(null);

        // Set background color for the frame
        mainFrame.getContentPane().setBackground(new Color(255, 228, 196)); // Bisque color

        // Add "CHAT APPLICATION" text at the center
        JLabel titleLabel = new JLabel("CHAT APPLICATION", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Cambria Math", Font.BOLD, 20));  // Set font and size
        titleLabel.setBounds(50, 20, 300, 40);  // Set the position and size of the label
        titleLabel.setForeground(new Color(0, 0, 139));  // Dark blue text color
        mainFrame.add(titleLabel);

        // "Login" button
        JButton loginButton = new JButton("Login");
        loginButton.setBounds(140, 100, 120, 40);
        loginButton.setFont(new Font("Cambria Math", Font.BOLD, 14)); // Set font
        loginButton.setForeground(Color.WHITE);  // Set text color
        loginButton.setBackground(new Color(0, 128, 255)); // Light blue background
        mainFrame.add(loginButton);

        // "Signup" button
        JButton signupButton = new JButton("Signup");
        signupButton.setBounds(140, 160, 120, 40);
        signupButton.setFont(new Font("Cambria Math", Font.BOLD, 14)); // Set font
        signupButton.setForeground(Color.WHITE); // Set text color
        signupButton.setBackground(new Color(34, 139, 34)); // Forest green background
        mainFrame.add(signupButton);

        // Add action listeners for buttons
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open Login Frame
                new LoginFrame();
            }
        });

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Open Signup Frame
                new SignupFrame();
            }
        });

        // Set frame visibility
        mainFrame.setVisible(true);
    }
}